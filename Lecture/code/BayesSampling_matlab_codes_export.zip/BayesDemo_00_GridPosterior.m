%% =========================================================================
%  BayesDemo_00_GridPosterior.m
%  GRID-BASED EXACT POSTERIOR  (Reference Solution)
% =========================================================================
%
%  TOY PROBLEM (identical across all BayesDemo scripts)
%  -------------------------------------------------------
%  Estimate P-wave velocity V from noisy travel-time observations.
%
%    Forward model : t_i = x_i / V          (straight-ray, surface source)
%    Likelihood    : t_i | V ~ N(x_i/V, sigma_d^2)   i.i.d.
%    Prior         : V ~ N(mu_pr, sigma_pr^2)
%
%  Because the forward model is nonlinear in V (linear in slowness 1/V),
%  the posterior p(V|d) has no closed analytical form in V-space.
%  This script evaluates it numerically on a fine grid -- the "exact"
%  reference against which IS, MH, and HMC will be compared.
%
%  OUTPUT
%  -------
%  Figure 1: data, prior, likelihood, and posterior profiles
%  Figure 2: annotated posterior with mean, MAP, and credible interval
% =========================================================================

clear; clc; rng(42);

%% ── 1. PROBLEM SETUP ─────────────────────────────────────────────────────

V_true   = 3.5;                % true P-wave velocity (km/s)
x        = [1; 3; 5; 8; 12];  % source-receiver offsets (km)
sigma_d  = 0.25;               % data noise std (s)
mu_pr    = 4.5;                % prior mean (km/s)
sigma_pr = 1.5;                % prior std  (km/s)
V_range  = [1.0, 7.0];        % search range (km/s)

% Simulate noisy observations
t_true = x / V_true;
d_obs  = t_true + sigma_d * randn(size(x));

fprintf('True velocity : %.2f km/s\n', V_true);
fprintf('Observed data : %s s\n', sprintf('%.3f  ', d_obs));

%% ── 2. EVALUATE PRIOR, LIKELIHOOD, AND POSTERIOR ON A GRID ──────────────

N_grid = 2000;
V_grid = linspace(V_range(1), V_range(2), N_grid)';   % (N_grid x 1)

% --- Prior p(V) ---
log_prior = -0.5 * ((V_grid - mu_pr) / sigma_pr).^2;
prior     = exp(log_prior - max(log_prior));   % numerically stable
prior     = prior / trapz(V_grid, prior);      % normalise

% --- Likelihood p(d|V) ---
%   log p(d|V) = -1/(2*sigma_d^2) * sum_i (d_i - x_i/V)^2
log_lik = zeros(N_grid, 1);
for k = 1:N_grid
    t_pred     = x / V_grid(k);
    log_lik(k) = -0.5 * sum((d_obs - t_pred).^2) / sigma_d^2;
end
likelihood = exp(log_lik - max(log_lik));
likelihood = likelihood / trapz(V_grid, likelihood);

% --- Unnormalised posterior: log p(V|d) = log p(d|V) + log p(V) ---
log_post = log_lik + log_prior;
log_post = log_post - max(log_post);   % subtract max for stability
posterior = exp(log_post);
posterior = posterior / trapz(V_grid, posterior);   % normalise

%% ── 3. POSTERIOR SUMMARY STATISTICS ─────────────────────────────────────

% Posterior mean  (numerical integration)
V_mean = trapz(V_grid, V_grid .* posterior);

% Posterior std
V_var  = trapz(V_grid, (V_grid - V_mean).^2 .* posterior);
V_std  = sqrt(V_var);

% MAP estimate (mode of posterior)
[~, idx_map] = max(posterior);
V_MAP = V_grid(idx_map);

% 95% credible interval (equal-tailed)
CDF        = cumtrapz(V_grid, posterior);
V_lo       = V_grid(find(CDF >= 0.025, 1));
V_hi       = V_grid(find(CDF >= 0.975, 1));

fprintf('\n--- Posterior Summary (Grid) ---\n');
fprintf('  MAP  estimate : %.4f km/s\n', V_MAP);
fprintf('  Mean estimate : %.4f km/s\n', V_mean);
fprintf('  Std deviation : %.4f km/s\n', V_std);
fprintf('  95%% CI        : [%.4f, %.4f] km/s\n', V_lo, V_hi);
fprintf('  True value    : %.4f km/s\n', V_true);

%% ── 4. FIGURE 1: PRIOR, LIKELIHOOD, POSTERIOR ───────────────────────────

figure('Name','Grid Posterior: Prior / Likelihood / Posterior', ...
       'Position',[80 80 1100 420]);

% -- Data fit panel
subplot(1,3,1);
x_plot = linspace(0, 14, 200);
hold on;
for k = 1:length(d_obs)
    xline(x(k), '--', 'Color',[0.7 0.7 0.7]);
end
plot(x_plot, x_plot / V_true, 'k-',  'LineWidth', 2.0, 'DisplayName','True model');
plot(x_plot, x_plot / V_mean, 'b-',  'LineWidth', 1.5, 'DisplayName','Post. mean');
plot(x_plot, x_plot / V_MAP,  'r--', 'LineWidth', 1.5, 'DisplayName','MAP');
plot(x, d_obs, 'ko', 'MarkerFaceColor','k', 'MarkerSize', 7, ...
    'DisplayName','Observed data');
xlabel('Offset x (km)'); ylabel('Travel time t (s)');
title('Data Fit'); legend('Location','northwest'); grid on; box on;

% -- Probability distributions panel
subplot(1,3,2); hold on;
plot(V_grid, prior,      'g-',  'LineWidth', 2.0, 'DisplayName','Prior p(V)');
plot(V_grid, likelihood, 'r-',  'LineWidth', 2.0, 'DisplayName','Likelihood p(d|V)');
plot(V_grid, posterior,  'b-',  'LineWidth', 2.5, 'DisplayName','Posterior p(V|d)');
xline(V_true, 'k--', 'LineWidth', 1.5, 'DisplayName','True V');
xlabel('Velocity V (km/s)'); ylabel('Probability density');
title('Prior  \times  Likelihood  =  Posterior'); legend; grid on; box on;
xlim(V_range);

% -- Log-posterior panel
subplot(1,3,3); hold on;
plot(V_grid, log_post,          'b-', 'LineWidth', 2.0);
xline(V_true, 'k--', 'LineWidth', 1.5, 'DisplayName','True V');
xline(V_MAP,  'r--', 'LineWidth', 1.5, 'DisplayName','MAP');
xlabel('Velocity V (km/s)'); ylabel('Log posterior (relative)');
title('Log Posterior'); legend({'Log posterior','True V','MAP'}); 
grid on; box on; xlim(V_range);

sgtitle('Grid-Based Exact Posterior  |  Toy Velocity Problem', ...
        'FontSize', 13, 'FontWeight', 'bold');

%% ── 5. FIGURE 2: ANNOTATED POSTERIOR WITH CREDIBLE INTERVAL ─────────────

figure('Name','Grid Posterior: Annotated','Position',[80 560 700 380]);
hold on;

% Shade 95% CI
mask = (V_grid >= V_lo) & (V_grid <= V_hi);
fill([V_grid(mask); flipud(V_grid(mask))], ...
     [posterior(mask); zeros(sum(mask),1)], ...
     [0.7 0.85 1.0], 'EdgeColor','none', 'DisplayName','95% Credible interval');

plot(V_grid, posterior, 'b-', 'LineWidth', 2.5, 'DisplayName','Posterior p(V|d)');
xline(V_true, 'k-',  'LineWidth', 2.0, 'DisplayName', sprintf('True V = %.2f',  V_true));
xline(V_MAP,  'r--', 'LineWidth', 1.5, 'DisplayName', sprintf('MAP   = %.3f',   V_MAP));
xline(V_mean, 'b--', 'LineWidth', 1.5, 'DisplayName', sprintf('Mean  = %.3f',   V_mean));

xlabel('Velocity V (km/s)'); ylabel('Posterior density');
title(sprintf('Posterior p(V|d)  —  Mean = %.3f ± %.3f km/s  |  95%% CI [%.3f, %.3f]', ...
    V_mean, V_std, V_lo, V_hi));
legend('Location','northwest'); grid on; box on; xlim(V_range);

%% ── 6. SAVE GRID POSTERIOR FOR COMPARISON PLOTS IN LATER SCRIPTS ────────

save('grid_posterior.mat', ...
     'V_grid','posterior','prior','likelihood', ...
     'V_mean','V_std','V_MAP','V_lo','V_hi', ...
     'V_true','x','d_obs','sigma_d','mu_pr','sigma_pr','V_range');

fprintf('\nSaved grid_posterior.mat  (loaded by IS / MH / HMC scripts)\n');
