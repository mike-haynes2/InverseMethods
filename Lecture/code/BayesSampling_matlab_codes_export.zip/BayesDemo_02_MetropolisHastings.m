%% =========================================================================
%  BayesDemo_02_MetropolisHastings.m
%  METROPOLIS-HASTINGS MCMC
% =========================================================================
%
%  TOY PROBLEM (identical across all BayesDemo scripts)
%  -------------------------------------------------------
%    Forward model : t_i = x_i / V
%    Likelihood    : t_i | V ~ N(x_i/V, sigma_d^2)   i.i.d.
%    Prior         : V ~ N(mu_pr, sigma_pr^2)
%
%  METROPOLIS-HASTINGS RECAP
%  --------------------------
%  Build a Markov chain whose stationary distribution is p(V|d).
%  At each step:
%    1. Propose  V* ~ q(V*|V_k) = N(V_k, sigma_q^2)   (symmetric RW)
%    2. Accept V* with probability
%         alpha = min(1, p(d|V*) p(V*) / [p(d|V_k) p(V_k)])
%       or equivalently:  log(alpha) = log pi(V*) - log pi(V_k)
%    3. Rejected proposals stay: V_{k+1} = V_k
%
%  This script demonstrates:
%    (A) Optimal step size  (~23% acceptance)
%    (B) Step size too small (chain barely moves)
%    (C) Step size too large (nearly all proposals rejected)
%
%  RUN BayesDemo_00_GridPosterior.m FIRST to generate grid_posterior.mat
% =========================================================================

clear; clc; rng(42);

%% ── 1. PROBLEM SETUP ─────────────────────────────────────────────────────

V_true   = 3.5;
x        = [1; 3; 5; 8; 12];
sigma_d  = 0.25;
mu_pr    = 4.5;
sigma_pr = 1.5;
V_range  = [1.0, 7.0];

rng(42);
t_true = x / V_true;
d_obs  = t_true + sigma_d * randn(size(x));

% Load grid reference
grid = load('grid_posterior.mat');

%% ── 2. METROPOLIS-HASTINGS ENGINE ────────────────────────────────────────

K        = 100000;   % total iterations
burn_frac = 0.20;    % fraction discarded as burn-in

function [chain, accept_rate] = run_MH(K, sigma_q, V_init, d_obs, x, ...
                                        sigma_d, mu_pr, sigma_pr, V_range)
%RUN_MH  Metropolis-Hastings with Gaussian random-walk proposal.
    chain    = zeros(1, K);
    chain(1) = V_init;
    lp_curr  = log_posterior(V_init, d_obs, x, sigma_d, mu_pr, sigma_pr);
    n_accept = 0;

    for k = 1:K-1
        % Propose
        V_prop = chain(k) + sigma_q * randn;

        % Reject immediately if outside physical range
        if V_prop < V_range(1) || V_prop > V_range(2)
            chain(k+1) = chain(k);
            continue
        end

        % Log acceptance ratio (symmetric proposal → only posterior ratio)
        lp_prop   = log_posterior(V_prop, d_obs, x, sigma_d, mu_pr, sigma_pr);
        log_alpha = lp_prop - lp_curr;

        % Accept / reject
        if log(rand) < log_alpha
            chain(k+1) = V_prop;
            lp_curr    = lp_prop;
            n_accept   = n_accept + 1;
        else
            chain(k+1) = chain(k);
        end
    end

    accept_rate = n_accept / (K-1) * 100;
end

%% ── 3. RUN THREE CHAINS WITH DIFFERENT STEP SIZES ───────────────────────

sigma_qs   = [0.05, 0.40, 3.0];     % too small, optimal, too large
labels     = {'(A) Too small  \sigma_q = 0.05', ...
              '(B) Optimal    \sigma_q = 0.40', ...
              '(C) Too large  \sigma_q = 3.00'};

V_init   = mu_pr;   % start at prior mean
k_burn   = round(burn_frac * K);
chains   = zeros(3, K);
acc_rates = zeros(1, 3);

for run = 1:3
    rng(42 + run);
    [chains(run,:), acc_rates(run)] = run_MH(K, sigma_qs(run), V_init, ...
        d_obs, x, sigma_d, mu_pr, sigma_pr, V_range);
    fprintf('Run %d (%s):  acceptance = %.1f%%\n', run, labels{run}, acc_rates(run));
end

% Post-burn-in samples for the optimal chain
samples_opt = chains(2, k_burn+1:end);
V_mh_mean   = mean(samples_opt);
V_mh_std    = std(samples_opt);

fprintf('\nOptimal chain posterior mean : %.4f km/s\n', V_mh_mean);
fprintf('Optimal chain posterior std  : %.4f km/s\n', V_mh_std);
fprintf('Grid reference mean          : %.4f km/s\n', grid.V_mean);

%% ── 4. FIGURE 1: TRACE PLOTS (FIRST 2000 ITERATIONS) ────────────────────

figure('Name','MH: Trace Plots','Position',[80 80 1100 680]);

for run = 1:3
    subplot(3,1,run); hold on;
    plot(1:2000, chains(run, 1:2000), 'Color',[0.4 0.6 0.8], 'LineWidth', 0.5);
    yline(V_true, 'k-',  'LineWidth', 1.8, 'DisplayName','True V');
    yline(V_mh_mean, 'r--', 'LineWidth', 1.2, 'DisplayName','Post. mean (opt.)');
    xline(k_burn/50, 'g--', 'LineWidth', 1.2, 'DisplayName','Burn-in end (scaled)');
    ylabel('V (km/s)');
    title(sprintf('%s   |   Acceptance rate = %.1f%%', labels{run}, acc_rates(run)));
    ylim(V_range); grid on; box on;
    if run == 1, legend('Location','northeast'); end
end
xlabel('Iteration');
sgtitle('Metropolis-Hastings Trace Plots  |  Effect of Step Size', ...
        'FontSize', 13, 'FontWeight', 'bold');

%% ── 5. FIGURE 2: AUTOCORRELATION COMPARISON ──────────────────────────────

max_lag = 300;
figure('Name','MH: Autocorrelation','Position',[80 560 1100 380]);

colors = {[0.8 0.2 0.2], [0.2 0.5 0.8], [0.2 0.7 0.3]};
for run = 1:3
    s = chains(run, k_burn+1:end);
    [acf, lags] = acf_manual(s, max_lag);
    subplot(1,3,run); hold on;
    stem(lags, acf, 'Color', colors{run}, 'MarkerSize', 2, 'LineWidth', 0.8);
    yline(0, 'k-');
    yline( 1.96/sqrt(length(s)), 'r--', 'LineWidth', 1.2);
    yline(-1.96/sqrt(length(s)), 'r--', 'LineWidth', 1.2);

    % Integrated autocorrelation time (rough estimate)
    tau = 1 + 2 * sum(acf(2:end));
    ESS_mh = length(s) / tau;
    title(sprintf('%s\n\\tau \\approx %.0f  |  ESS \\approx %.0f', ...
          labels{run}, tau, ESS_mh));
    xlabel('Lag'); ylabel('ACF'); grid on; box on;
    ylim([-0.3, 1.05]);
end
sgtitle('Autocorrelation Function  |  Post-Burn-In Chains', ...
        'FontSize', 12, 'FontWeight', 'bold');

%% ── 6. FIGURE 3: HISTOGRAM vs GRID POSTERIOR (optimal chain only) ────────

figure('Name','MH: Posterior Comparison','Position',[80 80 750 430]);
hold on;

histogram(samples_opt, 60, 'Normalization', 'pdf', ...
    'FaceColor', [0.5 0.7 0.9], 'EdgeColor', 'none', ...
    'DisplayName', sprintf('MH samples (N = %d)', length(samples_opt)));

plot(grid.V_grid, grid.posterior, 'r-', 'LineWidth', 2.5, ...
     'DisplayName', 'Grid (exact) posterior');

% 95% CI from MH
ci_lo = quantile(samples_opt, 0.025);
ci_hi = quantile(samples_opt, 0.975);
mask  = (grid.V_grid >= ci_lo) & (grid.V_grid <= ci_hi);
fill([grid.V_grid(mask); flipud(grid.V_grid(mask))], ...
     [grid.posterior(mask); zeros(sum(mask),1)], ...
     [1 0.8 0.8], 'EdgeColor','none', 'FaceAlpha', 0.4, ...
     'DisplayName','95% MH credible interval');

xline(V_true,   'k-',  'LineWidth', 2.0, 'DisplayName', sprintf('True V = %.2f', V_true));
xline(V_mh_mean,'b--', 'LineWidth', 1.5, 'DisplayName', sprintf('MH mean = %.3f', V_mh_mean));
xline(grid.V_mean,'r--','LineWidth', 1.5, 'DisplayName', sprintf('Grid mean = %.3f', grid.V_mean));

xlabel('V (km/s)'); ylabel('Posterior density');
title(sprintf('MH Posterior  |  \\sigma_q = 0.40  |  %.1f%% acceptance', acc_rates(2)));
legend('Location','northwest'); grid on; box on; xlim(V_range);

%% ── 7. SUMMARY TABLE ─────────────────────────────────────────────────────

fprintf('\n%-20s %12s %12s %12s\n', 'Method','Post. Mean','Post. Std','Accept. Rate');
fprintf('%s\n', repmat('-',1,60));
fprintf('%-20s %12.4f %12.4f %12s\n',   'Grid (exact)', grid.V_mean, grid.V_std, '---');
for run = 1:3
    s   = chains(run, k_burn+1:end);
    acf_vals = acf_manual(s, 500);
    tau = max(1, 1 + 2*sum(acf_vals(2:end)));
    fprintf('%-20s %12.4f %12.4f %10.1f%%  (ESS~%d)\n', ...
        sprintf('MH sigma_q=%.2f', sigma_qs(run)), ...
        mean(s), std(s), acc_rates(run), round(length(s)/tau));
end

%% ── LOCAL FUNCTIONS ──────────────────────────────────────────────────────

function lp = log_posterior(V, d_obs, x, sigma_d, mu_pr, sigma_pr)
%LOG_POSTERIOR  Unnormalised log posterior for the toy velocity problem.
    if V <= 0, lp = -inf; return; end
    t_pred  = x / V;
    log_lik = -0.5 * sum((d_obs - t_pred).^2) / sigma_d^2;
    log_pri = -0.5 * ((V - mu_pr) / sigma_pr)^2;
    lp      = log_lik + log_pri;
end

function [acf, lags] = acf_manual(x, max_lag)
%ACF_MANUAL  Normalized autocorrelation function up to max_lag.
    x    = x(:) - mean(x);
    var0 = mean(x.^2);
    lags = (0:max_lag)';
    acf  = zeros(max_lag+1, 1);
    for lag = 0:max_lag
        acf(lag+1) = mean(x(1:end-lag) .* x(lag+1:end)) / var0;
    end
end
