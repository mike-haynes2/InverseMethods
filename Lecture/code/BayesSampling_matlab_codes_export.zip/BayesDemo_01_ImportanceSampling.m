%% =========================================================================
%  BayesDemo_01_ImportanceSampling.m
%  IMPORTANCE SAMPLING
% =========================================================================
%
%  TOY PROBLEM (identical across all BayesDemo scripts)
%  -------------------------------------------------------
%    Forward model : t_i = x_i / V
%    Likelihood    : t_i | V ~ N(x_i/V, sigma_d^2)   i.i.d.
%    Prior         : V ~ N(mu_pr, sigma_pr^2)
%
%  IMPORTANCE SAMPLING RECAP
%  --------------------------
%  We cannot sample from the posterior p(V|d) directly, but we can
%  sample from a proposal q(V) and re-weight:
%
%    E[g(V)|d] ≈  sum_k  w_k g(V_k)  /  sum_k w_k
%
%  where  w_k = p(d|V_k) p(V_k) / q(V_k)   (unnormalised weight)
%
%  This script demonstrates:
%    (A) Good proposal  — Gaussian centred near the posterior
%    (B) Bad proposal   — Gaussian centred far from the posterior
%  and computes the Effective Sample Size (ESS) for each.
%
%  RUN BayesDemo_00_GridPosterior.m FIRST to generate grid_posterior.mat
% =========================================================================

clear; clc; rng(42);

%% ── 1. PROBLEM SETUP ─────────────────────────────────────────────────────

V_true   = 3.5;
x        = [1; 3; 5; 8; 12];
sigma_d  = 0.25;
mu_pr    = 4.5;
sigma_pr = 1.5;
V_range  = [1.0, 7.0];

rng(42);
t_true = x / V_true;
d_obs  = t_true + sigma_d * randn(size(x));

% Log-posterior function (unnormalised, up to a constant)
log_post_fn = @(V) log_posterior(V, d_obs, x, sigma_d, mu_pr, sigma_pr);

function lp = log_posterior(V, d_obs, x, sigma_d, mu_pr, sigma_pr)
%LOG_POSTERIOR  Unnormalised log posterior for the toy velocity problem.
%   log p(V|d) = log p(d|V) + log p(V)
    if V <= 0
        lp = -inf;
        return
    end
    t_pred  = x / V;
    log_lik = -0.5 * sum((d_obs - t_pred).^2) / sigma_d^2;
    log_pri = -0.5 * ((V - mu_pr) / sigma_pr)^2;
    lp = log_lik + log_pri;
end

%% ── 2. IMPORTANCE SAMPLING FUNCTION ─────────────────────────────────────

K = 50000;   % number of importance samples

% Helper: run IS and return weighted results
%   mu_q, sig_q  : proposal mean and std (Gaussian)
function [V_samp, w_norm, ESS, V_est, V_std_est] = ...
        run_IS(K, mu_q, sig_q, log_post_fn, V_range)

    % (a) Draw samples from proposal
    V_samp = mu_q + sig_q * randn(K, 1);

    % (b) Compute log importance weights: log w = log pi(V) - log q(V)
    log_q  = -0.5 * ((V_samp - mu_q) / sig_q).^2 - log(sig_q * sqrt(2*pi));
    log_pi = arrayfun(log_post_fn, V_samp);

    % Set weight to zero for samples outside physical range
    out_of_range        = (V_samp < V_range(1)) | (V_samp > V_range(2));
    log_pi(out_of_range) = -inf;

    log_w  = log_pi - log_q;

    % (c) Numerically stable normalisation (subtract max before exp)
    log_w_stable = log_w - max(log_w(isfinite(log_w)));
    w_raw        = exp(log_w_stable);
    w_raw(~isfinite(log_w)) = 0;
    w_norm = w_raw / sum(w_raw);   % normalised weights

    % (d) Posterior estimates
    V_est     = sum(w_norm .* V_samp);
    V_std_est = sqrt(sum(w_norm .* (V_samp - V_est).^2));

    % (e) Effective Sample Size
    ESS = 1 / sum(w_norm.^2);
end

%% ── 3. CASE A: GOOD PROPOSAL ─────────────────────────────────────────────
%   Centre proposal on the prior mean; use a moderate width.
%   The posterior is nearby and covered by the proposal tails.

mu_good  = mu_pr;          % prior mean -- a reasonable starting point
sig_good = sigma_pr;       % same width as prior

[Va, wa, ESS_a, Vmean_a, Vstd_a] = ...
    run_IS(K, mu_good, sig_good, log_post_fn, V_range);

fprintf('=== CASE A: Good Proposal q ~ N(%.1f, %.1f^2) ===\n', mu_good, sig_good);
fprintf('  Posterior mean : %.4f km/s  (true: %.4f)\n', Vmean_a, V_true);
fprintf('  Posterior std  : %.4f km/s\n', Vstd_a);
fprintf('  ESS            : %d / %d  (%.1f%%)\n', round(ESS_a), K, 100*ESS_a/K);

%% ── 4. CASE B: BAD PROPOSAL ──────────────────────────────────────────────
%   Centre proposal far from posterior; most samples get near-zero weight.

mu_bad  = 6.0;   % far from true V = 3.5
sig_bad = 0.4;   % also too narrow

[Vb, wb, ESS_b, Vmean_b, Vstd_b] = ...
    run_IS(K, mu_bad, sig_bad, log_post_fn, V_range);

fprintf('\n=== CASE B: Bad Proposal q ~ N(%.1f, %.1f^2) ===\n', mu_bad, sig_bad);
fprintf('  Posterior mean : %.4f km/s  (true: %.4f)\n', Vmean_b, V_true);
fprintf('  Posterior std  : %.4f km/s\n', Vstd_b);
fprintf('  ESS            : %d / %d  (%.2f%%)\n', round(ESS_b), K, 100*ESS_b/K);
fprintf('  (Weight degeneracy: a handful of samples dominate)\n');

%% ── 5. FIGURE 1: SIDE-BY-SIDE COMPARISON ────────────────────────────────

figure('Name','Importance Sampling Comparison','Position',[80 80 1200 800]);

for panel = 1:2

    if panel == 1
        V_samp = Va; w_norm = wa; ESS = ESS_a;
        mu_q = mu_good; sig_q = sig_good;
        V_est = Vmean_a; label = 'A: Good Proposal';
    else
        V_samp = Vb; w_norm = wb; ESS = ESS_b;
        mu_q = mu_bad; sig_q = sig_bad;
        V_est = Vmean_b; label = 'B: Bad Proposal';
    end

    % -- Proposal vs posterior
    % Load grid posterior for comparison
    grid_p = load('grid_posterior.mat');

    subplot(2, 3, (panel-1)*3 + 1); hold on;
    % Grid posterior
    plot(grid_p.V_grid, grid_p.posterior, 'b-', 'LineWidth', 2.5, ...
         'DisplayName','True posterior (grid)');
    % Proposal density
    V_plt = linspace(V_range(1), V_range(2), 500);
    q_plt = normpdf(V_plt, mu_q, sig_q);
    plot(V_plt, q_plt, 'r--', 'LineWidth', 2.0, ...
         'DisplayName', sprintf('Proposal N(%.1f, %.1f^2)', mu_q, sig_q));
    xline(V_true, 'k-', 'LineWidth', 1.5, 'DisplayName','True V');
    xline(V_est,  'g--', 'LineWidth', 1.5, 'DisplayName','IS estimate');
    xlabel('V (km/s)'); ylabel('Density');
    title(sprintf('[%s]\nProposal vs Posterior', label));
    legend('FontSize',8); grid on; box on; xlim(V_range);

    % -- Weight distribution
    subplot(2, 3, (panel-1)*3 + 2); hold on;
    w_sorted = sort(w_norm, 'descend');
    plot(cumsum(w_sorted), 'b-', 'LineWidth', 1.5);
    yline(0.9, 'r--', 'LineWidth', 1.2);
    n90 = find(cumsum(w_sorted) >= 0.9, 1);
    xline(n90, 'r--');
    xlabel('Samples (sorted by weight)');
    ylabel('Cumulative weight');
    title(sprintf('[%s]\n90%% of weight in top %d samples\nESS = %d / %d', ...
          label, n90, round(ESS), K));
    grid on; box on;

    % -- IS weighted histogram vs grid posterior
    subplot(2, 3, (panel-1)*3 + 3); hold on;
    % Weighted histogram using histogram with sample weights
    edges  = linspace(V_range(1), V_range(2), 60);
    [~,bin] = histc(V_samp, edges); %#ok<HISTC>
    Nbin   = length(edges) - 1;
    w_hist = zeros(Nbin, 1);
    for b = 1:Nbin
        w_hist(b) = sum(w_norm(bin == b));
    end
    bin_w  = edges(2) - edges(1);
    bar(edges(1:end-1) + bin_w/2, w_hist / bin_w, 1, ...
        'FaceColor', [0.6 0.8 1.0], 'EdgeColor', 'none', ...
        'DisplayName','IS weighted histogram');
    plot(grid_p.V_grid, grid_p.posterior, 'b-', 'LineWidth', 2.5, ...
         'DisplayName','True posterior');
    xline(V_true, 'k-', 'LineWidth', 1.5, 'DisplayName','True V');
    xlabel('V (km/s)'); ylabel('Density');
    title(sprintf('[%s]\nWeighted histogram vs true posterior', label));
    legend('FontSize', 8); grid on; box on; xlim(V_range);

end

sgtitle('Importance Sampling  |  Good vs Bad Proposal', ...
        'FontSize', 13, 'FontWeight', 'bold');

%% ── 6. FIGURE 2: WEIGHT DEGENERACY SCATTER ───────────────────────────────
%   Visualise how individual sample weights are distributed.

figure('Name','IS: Weight Distribution','Position',[80 560 1100 380]);

for panel = 1:2
    if panel == 1
        V_samp = Va; w_norm = wa; ESS = ESS_a; label = 'Good Proposal';
    else
        V_samp = Vb; w_norm = wb; ESS = ESS_b; label = 'Bad Proposal';
    end

    subplot(1, 2, panel); hold on;
    % Plot first 2000 samples coloured by their weight
    idx = 1:2000;
    scatter(idx, V_samp(idx), 8, log10(w_norm(idx) + 1e-20), 'filled');
    colorbar; colormap(gca, parula);
    yline(V_true, 'r-', 'LineWidth', 1.5);
    xlabel('Sample index'); ylabel('V (km/s)');
    title(sprintf('[%s]  ESS = %d / %d\nColour = log10(normalised weight)', ...
          label, round(ESS), K));
    grid on; box on;
end

sgtitle('Weight Degeneracy: Each dot = one IS sample, colour = weight', ...
        'FontSize', 12, 'FontWeight', 'bold');

%% ── LOCAL FUNCTION ───────────────────────────────────────────────────────


